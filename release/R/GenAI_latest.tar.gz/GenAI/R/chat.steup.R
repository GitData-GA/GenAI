#' Generate an empty chat history list of a Generative AI model
#'
#' This function establishes a connection to a Generative AI model by providing essential
#' parameters and generates an empty chat history list for a Generative AI model.
#'
#' @param model.parameters A character vector containing the Generative AI service provider,
#' corresponding model, version, API key, and proxy status.
#'
#' @return If successful, chat history list is generated for the Generative AI model.
#'
#' @details It is crucial to provide accurate and valid information for each parameter
#' to ensure successful text generation by the Generative AI model. The chat history will be
#' changed by this function. If any of the provided parameters is incorrect, the function
#' will respond with an error message based on the information received from the API.
#' Use the function \code{available.models()} to see all supported Generative AI models.
#'
#' @examples
#' \dontrun{
#'   # Get available models
#'   models = available.models()
#'
#'   # Connect to the model, replace API_KEY with your api key
#'   genai.model = connect.genai("google",
#'                               models$google$model[1],
#'                               models$google$version[1],
#'                               "API_KEY",
#'                               FALSE)
#'
#'   # Setup an empty chat history
#'   history = chat.steup(genai.model)
#' }
#'
#' @export
chat.steup = function(model.parameter) {
  switch (model.parameter["provider"],
          google = {
            requestBody = list(contents = list())
            return (requestBody)
          },
          openai = {
            requestBody = list(model = model.parameter["model"],
                               messages = list(list(role = "system",
                                                    content = "You are a helpful assistant.")))
            return (requestBody)
          })
}
