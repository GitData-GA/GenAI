#' @noRd
moderation.openai = function(model.parameter, prompt) {
  safety.URL = ifelse(
    model.parameter["proxy"],
    paste0(
      "https://api.genai.gd.edu.kg/openai/",
      model.parameter["version"],
      "/moderations"
    ),
    paste0(
      "https://api.openai.com/",
      model.parameter["version"],
      "/moderations"
    )
  )
  safety.check = list(input = prompt)
  safety.request = jsonlite::toJSON(safety.check, auto_unbox = TRUE)
  safety.response = httr::POST(
    url = safety.URL,
    body = safety.request,
    httr::add_headers(
      "Content-Type" = "application/json",
      "Authorization" = paste("Bearer", model.parameter["api"])
    )
  )
  safety.responseJSON = httr::content(safety.response, "parsed")
  if (safety.responseJSON$results[[1]]$flagged) {
    stop("Safety: The prompt may contain harmful content.")
  }
}

#' @noRd
image.to.data.uri = function(image.path) {
  image.data = ""
  if (grepl("^https?://", tolower(image.path))) {
    response = httr::GET(image.path)
    image.data = base64enc::base64encode(httr::content(response, type = "raw"))
  } else {
    image.data = base64enc::base64encode(readBin(image.path, "raw", file.info(image.path)$size))
  }
  return(c(tools::file_ext(image.path), image.data))
}