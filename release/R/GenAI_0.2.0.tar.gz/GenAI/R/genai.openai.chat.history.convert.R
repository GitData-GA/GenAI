#' @noRd
genai.openai.chat.history.convert = function(from.genai.openai.object,
                                             to.genai.object) {
  if (class(to.genai.object)[1] == "genai.google") {
    openai.history = from.genai.openai.object$chat.history$messages[2:length(from.genai.openai.object$chat.history$messages)]
    contents = lapply(openai.history, function(entry) {
      list(
        role = ifelse(entry$role == "assistant", "model", "user"),
        parts = list(text = entry$content)
      )
    })
    google.history = contents
    return(google.history)
  }
  else if (class(to.genai.object)[1] == "genai.moonshot") {
    moonshot.history = from.genai.openai.object$chat.history$messages
    moonshot.history[[1]]$content = "你是 Kimi，由 Moonshot AI 提供的人工智能助手，你更擅长中文和英文的对话。你会为用户提供安全，有帮助，准确的回答。同时，你会拒绝一些涉及恐怖主义，种族歧视，黄色暴力等问题的回答。Moonshot AI 为专有名词，不可翻译成其他语言。"
    return(moonshot.history)
  }
  else {
    stop("Invalid value for to.genai.object.")
  }
}
