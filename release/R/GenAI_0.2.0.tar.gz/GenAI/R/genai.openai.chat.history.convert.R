#' @noRd
genai.openai.chat.history.convert = function(from.genai.openai.object,
                                             to.genai.object) {
  if (class(to.genai.object)[1] == "genai.google") {
    openai.history = from.genai.openai.object$chat.history$messages[2:length(from.genai.openai.object$chat.history$messages)]
    contents = lapply(openai.history, function(entry) {
      list(
        role = ifelse(entry$role == "assistant", "model", "user"),
        parts = list(text = entry$content)
      )
    })
    google.history = list(contents)
    return(google.history)
  }
  else {
    stop("Invalid value for to.genai.object.")
  }
}
