#' @noRd
genai.moonshot.txt = function(genai.moonshot.object,
                              prompt,
                              verbose,
                              config = c(
                                max.tokens = NULL,
                                stream = NULL,
                                temperature = NULL,
                                top.p = NULL,
                              )) {
  # Check configurations
  genai.moonshot.config.check(config)

  # Get api url
  api.url = paste0(
    "https://api.moonshot.cn/",
    genai.moonshot.object$version,
    "/chat/completions"
  )
  if (genai.moonshot.object$proxy) {
    api.url = paste0(
      "https://api.genai.gd.edu.kg/moonshot/",
      genai.moonshot.object$version,
      "/chat/completions"
    )
  }

  # Initialize the request body
  requestBody = list(
    model = genai.moonshot.object$model,
    messages = list(
      list(role = "system",
           content = "你是 Kimi，由 Moonshot AI 提供的人工智能助手，你更擅长中文和英文的对话。你会为用户提供安全，有帮助，准确的回答。同时，你会拒绝一些涉及恐怖主义，种族歧视，黄色暴力等问题的回答。Moonshot AI 为专有名词，不可翻译成其他语言。"),
      list(role = "user",
           content = prompt)
    )
  )

  # Get the generation configuration
  if (length(config) > 0) {
    requestBody = genai.moonshot.generation.config(requestBody, config)
  }

  # Convert the request as JSON format
  requestBodyJSON = jsonlite::toJSON(requestBody,
                                     auto_unbox = TRUE,
                                     pretty = TRUE)

  # Send request and get response
  response = httr::POST(
    url = api.url,
    body = requestBodyJSON,
    httr::add_headers(
      "Content-Type" = "application/json",
      "Authorization" = paste("Bearer", genai.moonshot.object$api)
    )
  )
  responseJSON = httr::content(response, "parsed")

  # Check for response error
  if (!is.null(responseJSON$error)) {
    stop(responseJSON$error$message)
  }

  # Print detail if verbose is TRUE
  if (verbose) {
    genai.moonshot.formated.confguration(requestBody, prompt)
    cat("\n")
  }

  # Get the response text
  return (responseJSON$choices[[1]]$message$content)
}
