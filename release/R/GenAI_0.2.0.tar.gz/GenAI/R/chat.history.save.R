#' Chat History Save
#'
#' This function saves a chat history along with a generative AI object as a JSON file.
#'
#' @param genai.object A generative AI object containing necessary and correct information.
#' @param file.name A character string representing the name of the JSON file for the chat history.
#'
#' @return If successful, the chat history will be saved as a JSON file in your current or specified
#' directory.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful chat
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}.
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @examples
#' \dontrun{
#' all.models = available.models() %>% print()
#'
#' # Please change YOUR_GOOGLE_API to your own API key of Google Generative AI
#' Sys.setenv(GOOGLE_API = "YOUR_GOOGLE_API")
#'
#' # Create a Google Generative AI object
#' google = genai.google(api = Sys.getenv("GOOGLE_API"),
#'                       model = all.models$google$model[1],
#'                       version = all.models$google$version[1],
#'                       proxy = FALSE)
#'
#' # Generation configurations
#' parameters = list(
#   harm.category.dangerous.content = 5,
#'   harm.category.harassment = 5,
#'   max.output.tokens = 4096,
#'   temperature = 0.9
#' )
#'
#' # Start a chat session
#' prompts = c("Write a story about Mars in 50 words.",
#'             "Write a story about Jupiter in 50 words.",
#'             "Summarize the chat.")
#' for (prompt in prompts) {
#'   google %>%
#'     chat(prompt = prompt,
#'          verbose = FALSE,
#'          config = parameters) %>%
#'     strwrap(width = 76, exdent = 0) %>%
#'     paste(collapse = "\n") %>%
#'     cat("\n\n\n")
#' }
#'
#' # Method 1 (recommended): use the pipe operator "%>%"
#' google %>%
#'   chat.history.save(file.name = "openai.history")
#'
#' # Method 2: use the reference operator "$"
#' google$chat.history.save(file.name = "openai.history")
#'
#' # Method 3: use the function chat.history.save() directly
#' chat.history.save(genai.object = google,
#'                   file.name = "openai.history")
#'
#' # Please change YOUR_OPENAI_API to your own API key of OpenAI
#' Sys.setenv(OPENAI_API = "YOUR_OPENAI_API")
#'
#' # Please change YOUR_OPENAI_ORG to your own organization ID for OpenAI
#' Sys.setenv(OPENAI_ORG = "YOUR_OPENAI_ORG")
#'
#' # Create an OpenAI object
#' openai = genai.openai(api = Sys.getenv("OPENAI_API"),
#'                       model = all.models$openai$model[1],
#'                       version = all.models$openai$version[1],
#'                       proxy = FALSE,
#'                       organization.id = Sys.getenv("OPENAI_ORG"))
#'
#' # Generation configurations
#' parameters = list(
#'   frequency.penalty = 1,
#'   logprobs = FALSE,
#'   max.tokens = 3000,
#'   temperature = 0.9
#' )
#'
#' # Start a chat session
#' prompts = c("Write a story about Mars in 50 words.",
#'             "Write a story about Jupiter in 50 words.",
#'             "Summarize the chat.")
#' for (prompt in prompts) {
#'   openai %>%
#'     chat(prompt = prompt,
#'          verbose = FALSE,
#'          config = parameters) %>%
#'     strwrap(width = 76, exdent = 0) %>%
#'     paste(collapse = "\n") %>%
#'     cat("\n\n\n")
#' }
#'
#' # Method 1 (recommended): use the pipe operator "%>%"
#' openai %>%
#'   chat.history.save(file.name = "openai.history")
#'
#' # Method 2: use the reference operator "$"
#' openai$chat.history.save(file.name = "openai.history")
#'
#' # Method 3: use the function chat.history.save() directly
#' chat.history.save(genai.object = openai,
#'                   file.name = "openai.history")
#' }
#'
#' @export
chat.history.save = function(genai.object, file.name) {
  genai.object$chat.history.save(file.name)
}
