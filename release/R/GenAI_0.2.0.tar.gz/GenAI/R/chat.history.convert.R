#' Convert Chat History
#'
#' This function converts the chat history along with a generative AI object to a valid format
#' for another generative AI object.
#'
#' @param from.genai.object A source generative AI object containing necessary and correct information.
#' @param to.genai.object A target generative AI object containing necessary and correct information.
#'
#' @return If successful, the converted chat history list will be returned.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful chat
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}. Moreover, you can print out the chat history using the
#' function \code{\link{chat.history.print}} or simply use \code{verbose = TRUE} during the chat.
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @examples
#' \dontrun{
#' all.models = available.models() %>% print()
#'
#' # Please change YOUR_GOOGLE_API to your own API key of Google Generative AI
#' Sys.setenv(GOOGLE_API = "YOUR_GOOGLE_API")
#'
#' # Please change YOUR_OPENAI_API to your own API key of OpenAI
#' Sys.setenv(OPENAI_API = "YOUR_OPENAI_API")
#'
#' # Please change YOUR_OPENAI_ORG to your own organization ID for OpenAI
#' Sys.setenv(OPENAI_ORG = "YOUR_OPENAI_ORG")
#'
#' # Create a Google Generative AI object
#' google = genai.google(api = Sys.getenv("GOOGLE_API"),
#'                       model = all.models$google$model[1],
#'                       version = all.models$google$version[1],
#'                       proxy = FALSE)
#'
#' # Generation configurations
#' parameters = list(
#'   harm.category.dangerous.content = 5,
#'   harm.category.harassment = 5,
#'   max.output.tokens = 4096,
#'   temperature = 0.9
#' )
#'
#' # Start a chat session
#' prompts = c("Write a story about Mars in 50 words.",
#'             "Write a story about Jupiter in 50 words.",
#'             "Summarize the chat.")
#' for (prompt in prompts) {
#'   google %>%
#'     chat(prompt = prompt,
#'          verbose = FALSE,
#'          config = parameters) %>%
#'     strwrap(width = 76, exdent = 0) %>%
#'     paste(collapse = "\n") %>%
#'     cat("\n\n\n")
#' }
#'
#' # Create an OpenAI object
#' openai = genai.openai(api = Sys.getenv("OPENAI_API"),
#'                       model = all.models$openai$model[1],
#'                       version = all.models$openai$version[1],
#'                       proxy = FALSE,
#'                       organization.id = Sys.getenv("OPENAI_ORG"))
#'
#' # Generation configurations
#' parameters = list(
#'   frequency.penalty = 1,
#'   logprobs = FALSE,
#'   max.tokens = 3000,
#'   temperature = 0.9
#' )
#'
#' # Start a chat session
#' prompts = c("What is CatBoost? 50 words",
#'             "What is XGBoost? 50 words",
#'             "Summarize the chat.")
#' for (prompt in prompts) {
#'   openai %>%
#'     chat(prompt = prompt,
#'          verbose = FALSE,
#'          config = parameters) %>%
#'     strwrap(width = 76, exdent = 0) %>%
#'     paste(collapse = "\n") %>%
#'     cat("\n\n\n")
#' }
#'
#' # Convert the chat history in google to the format of openai
#' new.openai = google %>%
#'   chat.history.convert(openai)
#'
#' # Convert the chat history in openai to the format of google
#' new.google = openai %>%
#'   chat.history.convert(google)
#'
#' # Import the converted chat history for google
#' google %>%
#'   chat.history.import(new.google)
#'
#' # Print out the new history
#' google %>%
#'   chat.history.print()
#'
#' # Import the converted chat history for openai
#' openai %>%
#'   chat.history.import(new.openai)
#'
#' # Print out the new history
#' openai %>%
#'   chat.history.print()
#' }
#'
#' @export
chat.history.convert = function(from.genai.object,
                                to.genai.object) {
  from.genai.object$chat.history.convert(from.genai.object,
                                         to.genai.object)
}
