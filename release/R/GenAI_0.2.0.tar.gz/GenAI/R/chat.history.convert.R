#' Convert Chat History
#'
#' @export
chat.history.convert = function(from.genai.object,
                                to.genai.object) {
  from.genai.object$chat.history.convert(from.genai.object,
                                         to.genai.object)
}
