#' @noRd
genai.google.chat.history.convert = function(from.genai.google.object,
                                             to.genai.object) {
  if (class(to.genai.object)[1] == "genai.openai") {
    system.message = list(role = "system", content = "You are a helpful assistant.")
    messages = lapply(from.genai.google.object$chat.history$contents, function(entry) {
      list(
        role = ifelse(entry$role == "model", "assistant", "user"),
        content = entry$parts$text
      )
    })
    openai.history = list(system.message, messages)
    return(openai.history)
  }
  else {
    stop("Invalid value for to.genai.object.")
  }
}

