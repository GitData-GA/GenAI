#' @noRd
genai.google.chat.history.convert = function(from.genai.google.object,
                                             to.genai.object) {
  if (class(to.genai.object)[1] == "genai.openai") {
    system.message = list(role = "system", content = "You are a helpful assistant.")
    messages = lapply(from.genai.google.object$chat.history$contents, function(entry) {
      list(
        role = ifelse(entry$role == "model", "assistant", "user"),
        content = entry$parts$text
      )
    })
    openai.history = c(list(system.message), messages)
    return(openai.history)
  }
  else if (class(to.genai.object)[1] == "genai.moonshot") {
    system.message = list(role = "system", content = "你是 Kimi，由 Moonshot AI 提供的人工智能助手，你更擅长中文和英文的对话。你会为用户提供安全，有帮助，准确的回答。同时，你会拒绝一些涉及恐怖主义，种族歧视，黄色暴力等问题的回答。Moonshot AI 为专有名词，不可翻译成其他语言。")
    messages = lapply(from.genai.google.object$chat.history$contents, function(entry) {
      list(
        role = ifelse(entry$role == "model", "assistant", "user"),
        content = entry$parts$text
      )
    })
    moonshot.history = c(list(system.message), messages)
    return(moonshot.history)
  }
  else {
    stop("Invalid value for to.genai.object.")
  }
}

