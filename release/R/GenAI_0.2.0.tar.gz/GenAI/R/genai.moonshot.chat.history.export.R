#' @noRd
genai.moonshot.chat.history.export = function(genai.moonshot.object) {
  return (genai.moonshot.object$chat.history$messages)
}
