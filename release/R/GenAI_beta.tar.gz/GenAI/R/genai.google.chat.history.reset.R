#' @noRd
genai.google.chat.history.reset = function(genai.google.object) {
  genai.google.object$chat.history$contents = list()
}
