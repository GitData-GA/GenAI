#' @noRd
get.safety.setting <- S7::new_generic("get.safety.setting", "model")
S7::method(get.safety.setting, genai.google) <- function(model) {
  raw.harm.category = c(
    harm.category.dangerous.content = "HARM_CATEGORY_DANGEROUS_CONTENT",
    harm.category.harassment = "HARM_CATEGORY_HARASSMENT",
    harm.category.hate.speech = "HARM_CATEGORY_HATE_SPEECH",
    harm.category.sexually.explicit = "HARM_CATEGORY_SEXUALLY_EXPLICIT"
  )
  raw.harm.block.threshold = c(
    "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
    "BLOCK_LOW_AND_ABOVE",
    "BLOCK_MEDIUM_AND_ABOVE",
    "BLOCK_ONLY_HIGH",
    "BLOCK_NONE"
  )
  filled.harm <-
    lapply(names(raw.harm.category), function(harm) {
      if (length(prop(google.model, harm)) > 0) {
        safety.setting.object <- list("category" = raw.harm.category[harm],
                                      "threshold" = raw.harm.block.threshold[prop(google.model, harm)])
        return(safety.setting.object)
      } else {
        return(NULL)
      }
    })
  filled.harm <- Filter(Negate(is.null), filled.harm)
  return(filled.harm)
}

#' @noRd
get.generation.config <- S7::new_generic("get.generation.config", "model")
S7::method(get.generation.config, genai.google) <- function(model) {
  configuration = list()
  if (length(model@stop.sequences) > 0) {
    configuration$stopSequences = model@stop.sequences
  }
  if (length(model@candidate.count) > 0) {
    configuration$candidateCount = model@candidate.count
  }
  if (length(model@max.output.tokens) > 0) {
    configuration$maxOutputTokens = model@max.output.tokens
  }
  if (length(model@temperature) > 0) {
    configuration$temperature = model@temperature
  }
  if (length(model@top.p) > 0) {
    configuration$topP = model@top.p
  }
  if (length(model@top.k) > 0) {
    configuration$topK = model@top.k
  }
  return(configuration)
}
