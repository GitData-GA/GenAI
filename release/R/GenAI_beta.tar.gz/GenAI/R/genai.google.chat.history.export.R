#' @noRd
genai.google.chat.history.export = function(genai.google.object,
                                            format = "list") {
  format = match.arg(format, c("list", "json"), several.ok = FALSE)
  # Convert to a pretty list
  export.list = list()
  index = 1
  for (message in genai.google.object$chat.history$contents) {
    export.list[[index]] = list(role = message$role,
                                text = message$parts$text)
    index = index + 1
  }
  # Return as a list or a json object
  if (format == "list") {
    return (export.list)
  }
  else {
    return (jsonlite::toJSON(export.list, pretty = TRUE))
  }
}
