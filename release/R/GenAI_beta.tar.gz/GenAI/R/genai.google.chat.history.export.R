#' @noRd
genai.google.chat.history.export = function(genai.google.object) {
  return (genai.google.object$chat.history$contents)
}
