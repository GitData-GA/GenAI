#' @noRd
genai.google.chat.history.export = function(genai.google.object) {
  export.list = list()
  index = 1
  for (message in genai.google.object$chat.history$contents) {
    export.list[[index]] = list(role = message$role,
                                text = message$parts$text)
    index = index + 1
  }
  return (export.list)
}
