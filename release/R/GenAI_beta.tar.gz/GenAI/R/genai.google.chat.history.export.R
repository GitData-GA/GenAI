#' @noRd
genai.google.chat.history.export = function(genai.google.object,
                                            format) {
  format = match.arg(format, c("list", "json"), several.ok = FALSE)
  # Return as a list or a json object
  if (format == "list") {
    return (genai.google.object$chat.history$contents)
  }
  else {
    return (jsonlite::toJSON(genai.google.object$chat.history$contents,
                             pretty = TRUE))
  }
}
