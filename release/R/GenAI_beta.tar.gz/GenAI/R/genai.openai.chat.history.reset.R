#' @noRd
genai.openai.chat.history.reset = function(genai.openai.object) {
  genai.openai.object$chat.history$messages = list()
}
