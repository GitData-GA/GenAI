#' Image Generation with Text as the Input
#'
#' This function establishes a connection to a generative AI model through a generative AI object.
#' It generates an image response based on the provided prompt.
#'
#' @param genai.object A generative AI object containing necessary and correct information.
#' @param prompt A character string representing the query for image generation.
#' @param verbose Optional. Default to \code{FALSE}. A boolean value determining whether or not to print
#' out the details of the image request.
#' @param config Optional. Default to \code{list()}. A list of configuration parameters for image generation.
#'
#' @return If successful, a image response will be returned. If the API response indicates
#' an error, the function halts execution and provides an error message.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful image
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}.
#'
#' For \strong{OpenAI} models, available configurations are as follows. For more detail, please refer to
#' \href{https://platform.openai.com/docs/api-reference/images/create}{Create image}.
#'
#' \itemize{
#'    \item \code{quality}
#'
#'    Optional. A character string. The quality of the image that will be generated. \code{hd} creates
#'    images with finer details and greater consistency across the image.
#'
#'    \item \code{size}
#'
#'    Optional. A character string. The size of the generated images. Must be one of \code{256x256},
#'    \code{512x512}, or \code{1024x1024} for \code{dall-e-2}. Must be one of \code{1024x1024}, \code{1792x1024}, or
#'    \code{1024x1792} for \code{dall-e-3} models.
#'
#'    \item \code{style}
#'
#'    Optional. The style of the generated images. Must be one of \code{vivid} or \code{natural}. Vivid causes
#'    the model to lean towards generating hyper-real and dramatic images. Natural causes the model to produce
#'    more natural, less hyper-real looking images.
#'
#'    \item \code{user}
#'
#'    Optional. A character string. A unique identifier representing your end-user, which can help OpenAI to monitor
#'    and detect abuse.
#' }
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @export
img = function(genai.object,
               prompt,
               verbose = FALSE,
               config = list()) {
  genai.object$img(prompt,
                   verbose,
                   config)
}
