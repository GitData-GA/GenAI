#' Print Chat History
#'
#' This function prints out the chat history along with a generative AI object.
#'
#' @param genai.object A generative AI object containing necessary and correct information.
#' @param from Default to 1. An integer representing the first message in the chat history that needs
#' to be printed.
#' @param to Default to \code{NULL}, prints until the last message in the chat history. An integer
#' representing the last message in the chat history that needs to be printed.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful chat
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}.
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @examples
#' \dontrun{
#' # Please change YOUR_GOOGLE_API to your own API key of Google Generative AI
#' Sys.setenv(GOOGLE_API = "YOUR_GOOGLE_API")
#'
#' # Please change YOUR_OPENAI_API to your own API key of OpenAI
#' Sys.setenv(OPENAI_API = "YOUR_OPENAI_API")
#'
#' # Please change YOUR_OPENAI_ORG to your own organization ID for OpenAI
#' Sys.setenv(OPENAI_ORG = "YOUR_OPENAI_ORG")
#'
#' all.models = available.models() %>% print()
#'
#' # Create a Google Generative AI object
#' google = genai.google(api = Sys.getenv("GOOGLE_API"),
#'                       model = all.models$google$model[1],
#'                       version = all.models$google$version[1],
#'                       proxy = FALSE)
#'
#' # Generation configurations
#' parameters = list(
#'   harm.category.dangerous.content = 5,
#'   harm.category.harassment = 5,
#'   max.output.tokens = 4096,
#'   temperature = 0.9
#' )
#'
#' # Method 1 (recommended): use the pipe operator "%>%"
#' google %>%
#'   chat(prompt = "Write a story about Mars in 50 words.",
#'        verbose = FALSE,
#'        config = parameters) %>%
#'   cat()
#'
#' # Method 2: use the reference operator "$"
#' cat(google$chat(prompt = "Write a story about Jupiter in 50 words.",
#'                 verbose = FALSE,
#'                 config = parameters))
#'
#' # Method 3: use the function chat() directly
#' # Set verbose to TRUE to see the detail
#' cat(chat(genai.object = google,
#'          prompt = "Summarize the chat.",
#'          verbose = TRUE,
#'          config = parameters))
#'
#' # Create an OpenAI object
#' openai = genai.openai(api = Sys.getenv("OPENAI_API"),
#'                       model = all.models$openai$model[1],
#'                       version = all.models$openai$version[1],
#'                       proxy = FALSE,
#'                       organization.id = Sys.getenv("OPENAI_ORG"))
#'
#' # Generation configurations
#' parameters = list(
#'   frequency.penalty = 1,
#'   logprobs = FALSE,
#'   max.tokens = 3000,
#'   temperature = 0.9
#' )
#'
#' # Method 1 (recommended): use the pipe operator "%>%"
#' openai %>%
#'   chat(prompt = "Write a story about Mars in 50 words.",
#'        verbose = FALSE,
#'        config = parameters) %>%
#'   cat()
#'
#' # Method 2: use the reference operator "$"
#' cat(openai$chat(prompt = "Write a story about Jupiter in 50 words.",
#'                 verbose = FALSE,
#'                 config = parameters))
#'
#' # Method 3: use the function chat() directly
#' # Set verbose to TRUE to see the detail
#' cat(chat(genai.object = openai,
#'          prompt = "Summarize the chat.",
#'          verbose = TRUE,
#'          config = parameters))
#' }
#'
#' @export
chat.history.print = function(genai.object,
                              from = 1,
                              to = NULL) {
  genai.object$chat.history.print(from, to)
}
