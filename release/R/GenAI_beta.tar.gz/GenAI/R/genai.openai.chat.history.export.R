#' @noRd
genai.openai.chat.history.export = function(genai.openai.object) {
  return (genai.openai.object$chat.history$messages)
}
