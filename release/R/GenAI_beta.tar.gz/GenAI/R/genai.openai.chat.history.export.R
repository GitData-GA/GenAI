#' @noRd
genai.openai.chat.history.export = function(genai.openai.object,
                                            format) {
  format = match.arg(format, c("list", "json"), several.ok = FALSE)
  # Return as a list or a json object
  if (format == "list") {
    return (genai.openai.object$chat.history$messages)
  }
  else {
    return (jsonlite::toJSON(genai.openai.object$chat.history$messages,
                             pretty = TRUE))
  }
}
