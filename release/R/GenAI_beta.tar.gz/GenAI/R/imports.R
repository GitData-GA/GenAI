#' @import R6
#' @importFrom jsonlite toJSON
#' @importFrom httr GET POST add_headers content
#' @importFrom listenv listenv
#' @importFrom magrittr %>%
#' @importFrom magick image_read
NULL
