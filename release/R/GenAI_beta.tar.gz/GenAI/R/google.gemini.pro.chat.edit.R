#' @noRd
genai.google <- S7::new_class(
  package = "GenAI",
  name = "genai.google",
  properties = list(
    api = class_character
  )
)

#' @noRd
google.gemini.pro <- S7::new_class(
  package = "GenAI",
  name = "google.gemini.pro",
  parent = genai.google,
  properties = list(
    model = new_property(class_character, default = "gemini-pro"),
    version = class_character,
    proxy = new_property(class_logical, default = FALSE),
    verbose = new_property(class_logical, default = FALSE),
    chat.history = new_property(class_environment,
                                default = listenv::listenv(contents = list())),
    harm.category.dangerous.content = class_numeric,
    harm.category.harassment = class_numeric,
    harm.category.hate.speech = class_numeric,
    harm.category.sexually.explicit = class_numeric,
    stop.sequences = class_list,
    candidate.count = class_numeric,
    max.output.tokens = class_numeric,
    temperature = class_numeric,
    top.p = class_numeric,
    top.k = class_numeric
  ),
  validator = function(self) {
    # Check harm categories
    invalid.harm <- lapply(names(google.gemini.pro@properties[7:10]), function(harm) {
      if (length(prop(self, harm)) > 0 && is.na(match(prop(self, harm), c(1, 2, 3, 4, 5)))) {
        return(paste0("Invalid value for ", harm, ". It must be 1, 2, 3, 4, or 5.\n"))
      }
    })
    invalid.harm <- Filter(Negate(is.null), invalid.harm)
    if (length(invalid.harm) > 0) {
      stop(invalid.harm)
    }

    # Check stop sequence
    if (length(self@stop.sequences) > 5) {
      stop("Invalid value for stop.sequence. It can only have at most 5 strings.")
    }

    # Check model, version, and proxy
    json.data = jsonlite::fromJSON("https://genai.gd.edu.kg/model.json")
    if (is.na(match(self@model, json.data$google$model))) {
      stop("Invalid value for model. Refer to 'available.models()' to view the supported models.")
    }
    if (is.na(match(self@version, json.data$google$version))) {
      stop(
        "Invalid value for version. Refer to 'available.models()' to view the supported versions."
      )
    }
    if (is.na(match(self@proxy, c(TRUE, FALSE)))) {
      stop("Invalid value for proxy. It must be either TRUE or FALSE.")
    }

    # Check connection
    api.url = paste0(
      "https://generativelanguage.googleapis.com/",
      self@version,
      "/models/",
      self@model,
      "?key=",
      self@api
    )
    if (self@proxy) {
      api.url = paste0(
        "https://api.genai.gd.edu.kg/google/",
        self@version,
        "/models/",
        self@model,
        "?key=",
        self@api
      )
    }
    response = httr::GET(url = api.url,
                         httr::add_headers("Content-Type" = "application/json"))
    responseJSON = httr::content(response, "parsed")
    if (!is.null(responseJSON$error)) {
      stop(responseJSON$error$message)
    }
    if (response$status_code != 200) {
      stop(
        "Invalid parameter(s) detected. Please check the values for api, model, version, and proxy."
      )
    }
  }
)

#' Chat Edit
#'
#' @export
chat.edit <- S7::new_generic("chat.edit", c("model", "message.to.edit", "prompt"))
S7::method(chat.edit,
           list(google.gemini.pro,
                class_numeric,
                class_character)) <- function(model,
                                              message.to.edit,
                                              prompt) {
                  # Check if there are messages in the chat history
                  if (length(model@chat.history$contents) == 0) {
                    stop("Unable to edit any messages as the chat history is devoid of content.")
                  }

                  # Check message.to.edit
                  if (message.to.edit %% 2 == 0) {
                    stop("Invalid value for message.to.edit. You can only edit messages sent by a user role. Please use chat.history.print() to review the formatted chat history.")
                  }

                  # Get api url
                  api.url = paste0(
                    "https://generativelanguage.googleapis.com/",
                    model@version,
                    "/models/",
                    model@model,
                    ":generateContent?key=",
                    model@api
                  )
                  if (model@proxy) {
                    api.url = paste0(
                      "https://api.genai.gd.edu.kg/google/",
                      model@version,
                      "/models/",
                      model@model,
                      ":generateContent?key=",
                      model@api
                    )
                  }

                  # Initialize the request body
                  requestNewContent = list(list(role = "user",
                                                parts = list(text = prompt)))
                  requestBody = as.list(model@chat.history)
                  requestBody$contents = append(requestBody$contents[1:message.to.edit - 1],
                                                requestNewContent)

                  # Get the safety settings
                  safety.setting = get.safety.setting(model)
                  if (length(safety.setting) > 0) {
                    requestBody$safetySettings <- safety.setting
                  }

                  # Get the generation configuration
                  generation.config = get.generation.config(model)
                  if (length(generation.config) > 0) {
                    requestBody$generationConfig <- generation.config
                  }

                  # Convert the request as JSON format
                  requestBodyJSON = jsonlite::toJSON(requestBody,
                                                     auto_unbox = TRUE,
                                                     pretty = TRUE)

                  # Send request and get response
                  response = httr::POST(
                    url = api.url,
                    body = requestBodyJSON,
                    httr::add_headers("Content-Type" = "application/json")
                  )
                  responseJSON = httr::content(response, "parsed")

                  # Check for harmful prompt
                  if (!is.null(responseJSON$promptFeedback$blockReason)) {
                    stop("The prompt may contain harmful content.")
                  }

                  # Check for response error
                  if (!is.null(responseJSON$error)) {
                    stop(responseJSON$error$message)
                  }

                  # Save the most recent prompt to the chat history
                  model@chat.history$contents <- append(model@chat.history$contents[1:message.to.edit - 1],
                                                        requestNewContent)

                  # Save the most recent model response to the chat history
                  respondContent = list(list(
                    role = "model",
                    parts = list(text = responseJSON$candidates[[1]]$content$parts[[1]]$text)
                  ))
                  model@chat.history$contents <- append(model@chat.history$contents, respondContent)

                  if (model@verbose) {
                    get.formated.confguration(requestBody, prompt)
                    cat("============================================================\n")
                    cat("   Chat history \n")
                    cat("------------------------------------------------------------\n\n")
                    chat.history.print(google.model)
                    cat("============================================================\n\n\n\n")
                  }

                  # Get the response text
                  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
                }
