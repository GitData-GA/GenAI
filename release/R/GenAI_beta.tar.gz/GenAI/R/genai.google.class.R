#' @noRd
genai.google.class = R6Class(
  classname = "genai.google",
  public = list(
    # Initialize method
    initialize = function(api, model, version, proxy = FALSE) {
      genai.google.check(api, model, version, proxy)
      private$api = api
      private$model = model
      private$version = version
      private$proxy = proxy
    },
    # Chat generation
    chat = function(prompt,
                    verbose = FALSE,
                    config = list()) {
      genai.google.chat(private,
                        prompt,
                        verbose,
                        config)
    },
    # Chat edit
    chat.edit = function(prompt,
                         message.to.edit,
                         verbose = FALSE,
                         config = list()) {
      genai.google.chat.edit(private,
                             prompt,
                             message.to.edit,
                             verbose,
                             config)
    },
    # Print chat history
    chat.history.print = function(from = 1, to = NULL) {
      genai.google.chat.history.print(private, from, to)
    },
    # Reset chat history
    chat.history.reset = function() {
      genai.google.chat.history.reset(private)
    },
    # Export chat history
    chat.history.export = function(format = "list") {
      genai.google.chat.history.export(private, format)
    },
    # Text generation
    txt = function(prompt,
                   verbose = FALSE,
                   config = list()) {
      genai.google.txt(private,
                       prompt,
                       verbose,
                       config)
    },
    # Text generation with image as input
    txt.image = function(prompt,
                         image.path,
                         verbose = FALSE,
                         config = list()) {
      genai.google.txt.image(private,
                             prompt,
                             image.path,
                             verbose,
                             config)
    }
  ),
  private = list(
    name = "genai.google.class",
    api = NULL,
    model = NULL,
    version = NULL,
    proxy = FALSE,
    chat.history = listenv::listenv(contents = list())
  )
)
