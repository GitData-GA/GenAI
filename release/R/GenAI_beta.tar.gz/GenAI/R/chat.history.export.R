#' Export Chat History
#'
#' @export
chat.history.export = function(genai.object) {
  genai.object$chat.history.export()
}
