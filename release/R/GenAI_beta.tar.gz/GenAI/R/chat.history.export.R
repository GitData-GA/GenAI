#' Export Chat History
#'
#' @export
chat.history.export = function(genai.object,
                               format = "list") {
  genai.object$chat.history.export(format)
}
