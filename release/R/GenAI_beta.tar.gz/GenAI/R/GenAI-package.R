#' @rawNamespace if (getRversion() < "4.3.0") importFrom("S7", "@")
NULL

.onLoad <- function(...) { # nocov start
  S7::methods_register()
} # nocov end

#' @import S7
#' @importFrom jsonlite toJSON
#' @importFrom httr GET POST add_headers content
#' @importFrom listenv listenv
#' @importFrom magrittr %>%
NULL
