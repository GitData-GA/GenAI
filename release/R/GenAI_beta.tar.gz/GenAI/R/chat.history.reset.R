#' Reset Chat History
#'
#' This function resets the chat history along with a generative AI object.
#'
#' @param genai.object A generative AI object containing necessary and correct information.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful chat
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}.
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @examples
#' \dontrun{
#' all.models = available.models() %>% print()
#'
#' # Please change YOUR_GOOGLE_API to your own API key of Google Generative AI
#' Sys.setenv(GOOGLE_API = "YOUR_GOOGLE_API")
#'
#' # Create a Google Generative AI object
#' google = genai.google(api = Sys.getenv("GOOGLE_API"),
#'                       model = all.models$google$model[1],
#'                       version = all.models$google$version[1],
#'                       proxy = FALSE)
#'
#' # Generation configurations
#' parameters = list(
#   harm.category.dangerous.content = 5,
#'   harm.category.harassment = 5,
#'   max.output.tokens = 4096,
#'   temperature = 0.9
#' )
#'
#' # Start a chat session
#' prompts = c("Write a story about Mars in 50 words.",
#'             "Write a story about Jupiter in 50 words.",
#'             "Summarize the chat.")
#' for (prompt in prompts) {
#'   google %>%
#'     chat(prompt = prompt,
#'          verbose = FALSE,
#'          config = parameters) %>%
#'     strwrap(width = 76, exdent = 0) %>%
#'     paste(collapse = "\n") %>%
#'     cat("\n\n\n")
#' }
#'
#' # Method 1 (recommended): use the pipe operator "%>%"
#' google %>%
#'   chat.history.print()
#'
#' # Method 2: use the reference operator "$"
#' google$chat.history.print(from = 3)
#'
#' # Method 3: use the function chat.history.print() directly
#' chat.history.print(genai.object = google,
#'                    from = 3,
#'                    to = 5)
#'
#' # Please change YOUR_OPENAI_API to your own API key of OpenAI
#' Sys.setenv(OPENAI_API = "YOUR_OPENAI_API")
#'
#' # Please change YOUR_OPENAI_ORG to your own organization ID for OpenAI
#' Sys.setenv(OPENAI_ORG = "YOUR_OPENAI_ORG")
#'
#' # Create an OpenAI object
#' openai = genai.openai(api = Sys.getenv("OPENAI_API"),
#'                       model = all.models$openai$model[1],
#'                       version = all.models$openai$version[1],
#'                       proxy = FALSE,
#'                       organization.id = Sys.getenv("OPENAI_ORG"))
#'
#' # Generation configurations
#' parameters = list(
#'   frequency.penalty = 1,
#'   logprobs = FALSE,
#'   max.tokens = 3000,
#'   temperature = 0.9
#' )
#'
#' # Start a chat session
#' prompts = c("Write a story about Mars in 50 words.",
#'             "Write a story about Jupiter in 50 words.",
#'             "Summarize the chat.")
#' for (prompt in prompts) {
#'   openai %>%
#'     chat(prompt = prompt,
#'          verbose = FALSE,
#'          config = parameters) %>%
#'     strwrap(width = 76, exdent = 0) %>%
#'     paste(collapse = "\n") %>%
#'     cat("\n\n\n")
#' }
#'
#' # Method 1 (recommended): use the pipe operator "%>%"
#' openai %>%
#'   chat.history.print()
#'
#' # Method 2: use the reference operator "$"
#' openai$chat.history.print(from = 3)
#'
#' # Method 3: use the function chat.history.print() directly
#' chat.history.print(genai.object = openai,
#'                    from = 3,
#'                    to = 5)
#' }
#'
#' @export
chat.history.reset = function(genai.object) {
  genai.object$chat.history.reset()
}
