#' @noRd
genai.google <- S7::new_class(
  package = "GenAI",
  name = "genai.google",
  properties = list(
    api = class_character
  )
)

#' @noRd
google.gemini.pro <- S7::new_class(
  package = "GenAI",
  name = "google.gemini.pro",
  parent = genai.google,
  properties = list(
    model = new_property(class_character, default = "gemini-pro"),
    version = class_character,
    proxy = new_property(class_logical, default = FALSE),
    verbose = new_property(class_logical, default = FALSE),
    chat.history = new_property(class_environment,
                                default = listenv::listenv(contents = list())),
    harm.category.dangerous.content = class_numeric,
    harm.category.harassment = class_numeric,
    harm.category.hate.speech = class_numeric,
    harm.category.sexually.explicit = class_numeric,
    stop.sequences = class_list,
    candidate.count = class_numeric,
    max.output.tokens = class_numeric,
    temperature = class_numeric,
    top.p = class_numeric,
    top.k = class_numeric
  ),
  validator = function(self) {
    # Check harm categories
    invalid.harm <- lapply(names(google.gemini.pro@properties[7:10]), function(harm) {
      if (length(prop(self, harm)) > 0 && is.na(match(prop(self, harm), c(1, 2, 3, 4, 5)))) {
        return(paste0("Invalid value for ", harm, ". It must be 1, 2, 3, 4, or 5.\n"))
      }
    })
    invalid.harm <- Filter(Negate(is.null), invalid.harm)
    if (length(invalid.harm) > 0) {
      stop(invalid.harm)
    }

    # Check stop sequence
    if (length(self@stop.sequences) > 5) {
      stop("Invalid value for stop.sequence. It can only have at most 5 strings.")
    }

    # Check model, version, and proxy
    json.data = jsonlite::fromJSON("https://genai.gd.edu.kg/model.json")
    if (is.na(match(self@model, json.data$google$model))) {
      stop("Invalid value for model. Refer to 'available.models()' to view the supported models.")
    }
    if (is.na(match(self@version, json.data$google$version))) {
      stop(
        "Invalid value for version. Refer to 'available.models()' to view the supported versions."
      )
    }
    if (is.na(match(self@proxy, c(TRUE, FALSE)))) {
      stop("Invalid value for proxy. It must be either TRUE or FALSE.")
    }

    # Check connection
    api.url = paste0(
      "https://generativelanguage.googleapis.com/",
      self@version,
      "/models/",
      self@model,
      "?key=",
      self@api
    )
    if (self@proxy) {
      api.url = paste0(
        "https://api.genai.gd.edu.kg/google/",
        self@version,
        "/models/",
        self@model,
        "?key=",
        self@api
      )
    }
    response = httr::GET(url = api.url,
                         httr::add_headers("Content-Type" = "application/json"))
    responseJSON = httr::content(response, "parsed")
    if (!is.null(responseJSON$error)) {
      stop(responseJSON$error$message)
    }
    if (response$status_code != 200) {
      stop(
        "Invalid parameter(s) detected. Please check the values for api, model, version, and proxy."
      )
    }
  }
)

#' Google Generative AI Text Generation with Image as Input
#'
#' @export
txt.image <- S7::new_generic("txt.image", c("model", "prompt", "image.path"))
S7::method(txt.image,
           list(google.gemini.pro,
                class_character,
                class_character)) <- function(model,
                                              prompt,
                                              image.path) {
                  # Get api url
                  api.url = paste0(
                    "https://generativelanguage.googleapis.com/",
                    model@version,
                    "/models/",
                    model@model,
                    ":generateContent?key=",
                    model@api
                  )
                  if (model@proxy) {
                    api.url = paste0(
                      "https://api.genai.gd.edu.kg/google/",
                      model@version,
                      "/models/",
                      model@model,
                      ":generateContent?key=",
                      model@api
                    )
                  }

                  # Convert image to data uri
                  img.info = image.to.data.uri(image.path)
                  if (img.info[1] == "jpg") {
                    img.info[1] = "jpeg"
                  }

                  # Initialize the request body
                  requestBody = list(
                    contents = list(parts = list(
                      list(text = prompt),
                      list(inline_data = list(
                        mime_type = paste0("image/", img.info[1]),
                        data = img.info[2]
                      ))
                    ))
                  )

                  # Get the safety settings
                  safety.setting = get.safety.setting(model)
                  if (length(safety.setting) > 0) {
                    requestBody$safetySettings <- safety.setting
                  }

                  # Get the generation configuration
                  generation.config = get.generation.config(model)
                  if (length(generation.config) > 0) {
                    requestBody$generationConfig <- generation.config
                  }

                  # Convert the request as JSON format
                  requestBodyJSON = jsonlite::toJSON(requestBody,
                                                     auto_unbox = TRUE,
                                                     pretty = TRUE)

                  # Send request and get response
                  response = httr::POST(
                    url = api.url,
                    body = requestBodyJSON,
                    httr::add_headers("Content-Type" = "application/json")
                  )
                  responseJSON = httr::content(response, "parsed")

                  # Check for harmful prompt
                  if (!is.null(responseJSON$promptFeedback$blockReason)) {
                    stop("The prompt may contain harmful content.")
                  }

                  # Check for response error
                  if (!is.null(responseJSON$error)) {
                    stop(responseJSON$error$message)
                  }

                  if (model@verbose) {
                    get.formated.confguration(requestBody, prompt)
                    cat("============================================================\n")
                    cat("   Image Path\n")
                    cat("------------------------------------------------------------\n")
                    cat(image.path, "\n")
                    cat("============================================================\n\n\n")
                    cat("\n")
                  }

                  # Get the response text
                  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
                }
