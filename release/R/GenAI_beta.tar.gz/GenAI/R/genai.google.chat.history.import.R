#' @noRd
genai.google.chat.history.import = function(genai.google.object,
                                            new.chat.history) {
  expected.format = list(
    role = NA,
    parts = list(
      text = NA
    )
  )
  # Imported chat history is a list
  if (is.list(new.chat.history)) {
    for (message in new.chat.history) {
      if (!identical(names(message), names(expected.format)) ||
          !is.character(message$role) ||
          !is.list(message$parts) ||
          length(message$parts) != 1 ||
          !is.character(message$parts$text)) {
        stop("Invalid value for new.chat.history. Please make sure the format of the imported chat history is correct.")
      }
    }
    genai.google.object$chat.history$contents = new.chat.history
  }
  # Imported chat history is a json object
  else if (tryCatch(jsonlite::fromJSON(new.chat.history),
               error = function(e) {
                 stop("Invalid value for new.chat.history. Please make sure the json is valid.")
               })
      ) {
    converted.chat.list = jsonlite::fromJSON(new.chat.history)
    for (message in converted.chat.list) {
      if (!identical(names(message), names(expected.format)) ||
          !is.character(message$role) ||
          !is.list(message$parts) ||
          length(message$parts) != 1 ||
          !is.character(message$parts$text)) {
        stop("Invalid value for new.chat.history. Please make sure the format of the imported chat history is correct.")
      }
    }
    genai.google.object$chat.history$contents = converted.chat.list
  }
  else {
    stop("Invalid new.chat.history. The only allowed formats are list and json.")
  }
}
