#' @noRd
genai.google <- S7::new_class(
  package = "GenAI",
  name = "genai.google",
  properties = list(
    api = class_character,
    model = class_character,
    version = class_character,
    proxy = new_property(class_logical, default = FALSE),
    verbose = new_property(class_logical, default = FALSE),
    chat.history = new_property(class_environment,
                                default = listenv::listenv(contents = list())),
    harm.category.dangerous.content = class_numeric,
    harm.category.harassment = class_numeric,
    harm.category.hate.speech = class_numeric,
    harm.category.sexually.explicit = class_numeric,
    stop.sequences = class_list,
    candidate.count = class_numeric,
    max.output.tokens = class_numeric,
    temperature = class_numeric,
    top.p = class_numeric,
    top.k = class_numeric
  ),
  validator = function(self) {
    # Check harm categories
    invalid.harm <- lapply(names(genai.google@properties[7:10]), function(harm) {
      if (length(prop(self, harm)) > 0 && is.na(match(prop(self, harm), c(1, 2, 3, 4, 5)))) {
        return(paste0("Invalid value for ", harm, ". It must be 1, 2, 3, 4, or 5.\n"))
      }
    })
    invalid.harm <- Filter(Negate(is.null), invalid.harm)
    if (length(invalid.harm) > 0) {
      stop(invalid.harm)
    }

    # Check stop sequence
    if (length(self@stop.sequences) > 5) {
      stop("Invalid value for stop.sequence. It can only have at most 5 strings.")
    }

    # Check model, version, and proxy
    json.data = jsonlite::fromJSON("https://genai.gd.edu.kg/model.json")
    if (is.na(match(self@model, json.data$google$model))) {
      stop("Invalid value for model. Refer to 'available.models()' to view the supported models.")
    }
    if (is.na(match(self@version, json.data$google$version))) {
      stop(
        "Invalid value for version. Refer to 'available.models()' to view the supported versions."
      )
    }
    if (is.na(match(self@proxy, c(TRUE, FALSE)))) {
      stop("Invalid value for proxy. It must be either TRUE or FALSE.")
    }

    # Check connection
    api.url = paste0(
      "https://generativelanguage.googleapis.com/",
      self@version,
      "/models/",
      self@model,
      "?key=",
      self@api
    )
    if (self@proxy) {
      api.url = paste0(
        "https://api.genai.gd.edu.kg/google/",
        self@version,
        "/models/",
        self@model,
        "?key=",
        self@api
      )
    }
    response = httr::GET(url = api.url,
                         httr::add_headers("Content-Type" = "application/json"))
    responseJSON = httr::content(response, "parsed")
    if (!is.null(responseJSON$error)) {
      stop(responseJSON$error$message)
    }
    if (response$status_code != 200) {
      stop(
        "Invalid parameter(s) detected. Please check the values for api, model, version, and proxy."
      )
    }
  }
)

#' @noRd
get.safety.setting <- S7::new_generic("get.safety.setting", "model")
S7::method(get.safety.setting, genai.google) <- function(model) {
  raw.harm.category = c(
    harm.category.dangerous.content = "HARM_CATEGORY_DANGEROUS_CONTENT",
    harm.category.harassment = "HARM_CATEGORY_HARASSMENT",
    harm.category.hate.speech = "HARM_CATEGORY_HATE_SPEECH",
    harm.category.sexually.explicit = "HARM_CATEGORY_SEXUALLY_EXPLICIT"
  )
  raw.harm.block.threshold = c(
    "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
    "BLOCK_LOW_AND_ABOVE",
    "BLOCK_MEDIUM_AND_ABOVE",
    "BLOCK_ONLY_HIGH",
    "BLOCK_NONE"
  )
  filled.harm <-
    lapply(names(raw.harm.category), function(harm) {
      if (length(prop(google.model, harm)) > 0) {
        safety.setting.object <- list("category" = raw.harm.category[harm],
                                      "threshold" = raw.harm.block.threshold[prop(google.model, harm)])
        return(safety.setting.object)
      } else {
        return(NULL)
      }
    })
  filled.harm <- Filter(Negate(is.null), filled.harm)
  return(filled.harm)
}

#' @noRd
get.generation.config <- S7::new_generic("get.generation.config", "model")
S7::method(get.generation.config, genai.google) <- function(model) {
  configuration = list()
  if (length(model@stop.sequences) > 0) {
    configuration$stopSequences = model@stop.sequences
  }
  if (length(model@candidate.count) > 0) {
    configuration$candidateCount = model@candidate.count
  }
  if (length(model@max.output.tokens) > 0) {
    configuration$maxOutputTokens = model@max.output.tokens
  }
  if (length(model@temperature) > 0) {
    configuration$temperature = model@temperature
  }
  if (length(model@top.p) > 0) {
    configuration$topP = model@top.p
  }
  if (length(model@top.k) > 0) {
    configuration$topK = model@top.k
  }
  return(configuration)
}

#' @noRd
txt <- S7::new_generic("txt", c("model", "prompt"))
S7::method(txt,
       list(genai.google,
            class_character)) <- function(model,
                                          prompt) {
              # Get api url
              api.url = paste0(
                "https://generativelanguage.googleapis.com/",
                model@version,
                "/models/",
                model@model,
                ":generateContent?key=",
                model@api
              )
              if (model@proxy) {
                api.url = paste0(
                  "https://api.genai.gd.edu.kg/google/",
                  model@version,
                  "/models/",
                  model@model,
                  ":generateContent?key=",
                  model@api
                )
              }

              # Initialize the request body
              requestBody = list(contents = list(parts = list(text = prompt)))

              # Get the safety settings
              safety.setting = get.safety.setting(model)
              if (length(safety.setting) > 0) {
                requestBody$safetySettings <- safety.setting
              }

              # Get the generation configuration
              generation.config = get.generation.config(model)
              if (length(generation.config) > 0) {
                requestBody$generationConfig <- generation.config
              }

              # Convert the request as JSON format
              requestBodyJSON = jsonlite::toJSON(requestBody,
                                                 auto_unbox = TRUE,
                                                 pretty = TRUE)

              # Send request and get response
              response = httr::POST(
                url = api.url,
                body = requestBodyJSON,
                httr::add_headers("Content-Type" = "application/json")
              )
              responseJSON = httr::content(response, "parsed")

              # Check for harmful prompt
              if (!is.null(responseJSON$blockReason)) {
                stop("The prompt may contain harmful content.")
              }

              # Check for response error
              if (!is.null(responseJSON$error)) {
                stop(responseJSON$error$message)
              }

              if (model@verbose) {
                cat("============================================================\n")
                cat("   Request and model information\n")
                cat("------------------------------------------------------------\n")
                cat(requestBodyJSON, "\n")
                cat("============================================================\n")
                cat("   Model responose\n")
                cat("------------------------------------------------------------\n")
              }

              # Get the response text
              return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
            }

#' @noRd
chat <- S7::new_generic("chat", c("model", "prompt"))
S7::method(chat,
       list(genai.google,
            class_character)) <- function(model,
                                          prompt) {
              # Get api url
              api.url = paste0(
                "https://generativelanguage.googleapis.com/",
                model@version,
                "/models/",
                model@model,
                ":generateContent?key=",
                model@api
              )
              if (model@proxy) {
                api.url = paste0(
                  "https://api.genai.gd.edu.kg/google/",
                  model@version,
                  "/models/",
                  model@model,
                  ":generateContent?key=",
                  model@api
                )
              }

              # Initialize the request body
              requestNewContent = list(list(role = "user",
                                            parts = list(text = prompt)))
              requestBody = as.list(model@chat.history)
              requestBody$contents = append(requestBody$contents, requestNewContent)

              # Get the safety settings
              safety.setting = get.safety.setting(model)
              if (length(safety.setting) > 0) {
                requestBody$safetySettings <- safety.setting
              }

              # Get the generation configuration
              generation.config = get.generation.config(model)
              if (length(generation.config) > 0) {
                requestBody$generationConfig <- generation.config
              }

              # Convert the request as JSON format
              requestBodyJSON = jsonlite::toJSON(requestBody,
                                                 auto_unbox = TRUE,
                                                 pretty = TRUE)

              # Send request and get response
              response = httr::POST(
                url = api.url,
                body = requestBodyJSON,
                httr::add_headers("Content-Type" = "application/json")
              )
              responseJSON = httr::content(response, "parsed")

              # Check for harmful prompt
              if (!is.null(responseJSON$blockReason)) {
                stop("The prompt may contain harmful content.")
              }

              # Check for response error
              if (!is.null(responseJSON$error)) {
                stop(responseJSON$error$message)
              }

              # Save the most recent prompt to the chat history
              model@chat.history$contents <- append(model@chat.history$contents, requestNewContent)

              # Save the most recent model response to the chat history
              respondContent = list(list(
                role = "model",
                parts = list(text = responseJSON$candidates[[1]]$content$parts[[1]]$text)
              ))
              model@chat.history$contents <- append(model@chat.history$contents, respondContent)

              if (model@verbose) {
                cat("============================================================\n")
                cat("   Request and model informationn\n")
                cat("------------------------------------------------------------\n")
                cat(requestBodyJSON, "\n")
                cat("============================================================\n")
                cat("   Chat history \n")
                cat("------------------------------------------------------------\n")
                cat(jsonlite::toJSON(as.list(model@chat.history), auto_unbox = TRUE, pretty = TRUE), "\n")
                cat("============================================================\n")
                cat("   Model responose\n")
                cat("------------------------------------------------------------\n")
              }

              # Get the response text
              return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
            }
