#' Google Generative AI Object
#'
#' @export
genai.google <- S7::new_class(
  package = "GenAI",
  name = "genai.google",
  properties = list(
    api = class_character,
    model = class_character,
    version = class_character,
    proxy = new_property(class_logical, default = FALSE),
    verbose = new_property(class_logical, default = FALSE),
    chat.history = new_property(class_environment,
                                default = listenv::listenv(contents = list())),
    harm.category.dangerous.content = class_numeric,
    harm.category.harassment = class_numeric,
    harm.category.hate.speech = class_numeric,
    harm.category.sexually.explicit = class_numeric,
    stop.sequences = class_list,
    candidate.count = class_numeric,
    max.output.tokens = class_numeric,
    temperature = class_numeric,
    top.p = class_numeric,
    top.k = class_numeric
  ),
  validator = function(self) {
    # Check harm categories
    invalid.harm <- lapply(names(genai.google@properties[7:10]), function(harm) {
      if (length(prop(self, harm)) > 0 && is.na(match(prop(self, harm), c(1, 2, 3, 4, 5)))) {
        return(paste0("Invalid value for ", harm, ". It must be 1, 2, 3, 4, or 5.\n"))
      }
    })
    invalid.harm <- Filter(Negate(is.null), invalid.harm)
    if (length(invalid.harm) > 0) {
      stop(invalid.harm)
    }

    # Check stop sequence
    if (length(self@stop.sequences) > 5) {
      stop("Invalid value for stop.sequence. It can only have at most 5 strings.")
    }

    # Check model, version, and proxy
    json.data = jsonlite::fromJSON("https://genai.gd.edu.kg/model.json")
    if (is.na(match(self@model, json.data$google$model))) {
      stop("Invalid value for model. Refer to 'available.models()' to view the supported models.")
    }
    if (is.na(match(self@version, json.data$google$version))) {
      stop(
        "Invalid value for version. Refer to 'available.models()' to view the supported versions."
      )
    }
    if (is.na(match(self@proxy, c(TRUE, FALSE)))) {
      stop("Invalid value for proxy. It must be either TRUE or FALSE.")
    }

    # Check connection
    api.url = paste0(
      "https://generativelanguage.googleapis.com/",
      self@version,
      "/models/",
      self@model,
      "?key=",
      self@api
    )
    if (self@proxy) {
      api.url = paste0(
        "https://api.genai.gd.edu.kg/google/",
        self@version,
        "/models/",
        self@model,
        "?key=",
        self@api
      )
    }
    response = httr::GET(url = api.url,
                         httr::add_headers("Content-Type" = "application/json"))
    responseJSON = httr::content(response, "parsed")
    if (!is.null(responseJSON$error)) {
      stop(responseJSON$error$message)
    }
    if (response$status_code != 200) {
      stop(
        "Invalid parameter(s) detected. Please check the values for api, model, version, and proxy."
      )
    }
  }
)

#' Google Generative AI Text Generation
#'
#' @export
txt <- S7::new_generic("txt", c("model", "prompt"))
S7::method(txt,
           list(genai.google,
                class_character)) <- function(model,
                                              prompt) {
                  # Get api url
                  api.url = paste0(
                    "https://generativelanguage.googleapis.com/",
                    model@version,
                    "/models/",
                    model@model,
                    ":generateContent?key=",
                    model@api
                  )
                  if (model@proxy) {
                    api.url = paste0(
                      "https://api.genai.gd.edu.kg/google/",
                      model@version,
                      "/models/",
                      model@model,
                      ":generateContent?key=",
                      model@api
                    )
                  }
                  
                  # Initialize the request body
                  requestBody = list(contents = list(parts = list(text = prompt)))
                  
                  # Get the safety settings
                  safety.setting = get.safety.setting(model)
                  if (length(safety.setting) > 0) {
                    requestBody$safetySettings <- safety.setting
                  }
                  
                  # Get the generation configuration
                  generation.config = get.generation.config(model)
                  if (length(generation.config) > 0) {
                    requestBody$generationConfig <- generation.config
                  }
                  
                  # Convert the request as JSON format
                  requestBodyJSON = jsonlite::toJSON(requestBody,
                                                     auto_unbox = TRUE,
                                                     pretty = TRUE)
                  
                  # Send request and get response
                  response = httr::POST(
                    url = api.url,
                    body = requestBodyJSON,
                    httr::add_headers("Content-Type" = "application/json")
                  )
                  responseJSON = httr::content(response, "parsed")
                  
                  # Check for harmful prompt
                  if (!is.null(responseJSON$promptFeedback$blockReason)) {
                    stop("The prompt may contain harmful content.")
                  }
                  
                  # Check for response error
                  if (!is.null(responseJSON$error)) {
                    stop(responseJSON$error$message)
                  }
                  
                  if (model@verbose) {
                    get.formated.confguration(requestBody, prompt)
                    cat("\n")
                  }
                  
                  # Get the response text
                  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
                }


#' Google Generative AI Text Generation with Image as Input
#'
#' @export
txt.image <- S7::new_generic("txt.image", c("model", "prompt", "image.path"))
S7::method(txt.image,
           list(genai.google,
                class_character,
                class_character)) <- function(model,
                                              prompt,
                                              image.path) {
                  # Get api url
                  api.url = paste0(
                    "https://generativelanguage.googleapis.com/",
                    model@version,
                    "/models/",
                    model@model,
                    ":generateContent?key=",
                    model@api
                  )
                  if (model@proxy) {
                    api.url = paste0(
                      "https://api.genai.gd.edu.kg/google/",
                      model@version,
                      "/models/",
                      model@model,
                      ":generateContent?key=",
                      model@api
                    )
                  }
                  
                  # Convert image to data uri
                  img.info = image.to.data.uri(image.path)
                  if (img.info[1] == "jpg") {
                    img.info[1] = "jpeg"
                  }
                  
                  # Initialize the request body
                  requestBody = list(
                    contents = list(parts = list(
                      list(text = prompt),
                      list(inline_data = list(
                        mime_type = paste0("image/", img.info[1]),
                        data = img.info[2]
                      ))
                    ))
                  )

                  # Get the safety settings
                  safety.setting = get.safety.setting(model)
                  if (length(safety.setting) > 0) {
                    requestBody$safetySettings <- safety.setting
                  }

                  # Get the generation configuration
                  generation.config = get.generation.config(model)
                  if (length(generation.config) > 0) {
                    requestBody$generationConfig <- generation.config
                  }

                  # Convert the request as JSON format
                  requestBodyJSON = jsonlite::toJSON(requestBody,
                                                     auto_unbox = TRUE,
                                                     pretty = TRUE)

                  # Send request and get response
                  response = httr::POST(
                    url = api.url,
                    body = requestBodyJSON,
                    httr::add_headers("Content-Type" = "application/json")
                  )
                  responseJSON = httr::content(response, "parsed")
                  
                  # Check for harmful prompt
                  if (!is.null(responseJSON$promptFeedback$blockReason)) {
                    stop("The prompt may contain harmful content.")
                  }

                  # Check for response error
                  if (!is.null(responseJSON$error)) {
                    stop(responseJSON$error$message)
                  }

                  if (model@verbose) {
                    get.formated.confguration(requestBody, prompt)
                    cat("============================================================\n")
                    cat("   Image Path\n")
                    cat("------------------------------------------------------------\n")
                    cat(image.path, "\n")
                    cat("============================================================\n\n\n")
                    cat("\n")
                  }

                  # Get the response text
                  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
                }

#' Google Generative AI Chat Generation
#'
#' @export
chat <- S7::new_generic("chat", c("model", "prompt"))
S7::method(chat,
           list(genai.google,
                class_character)) <- function(model,
                                              prompt) {
                  # Get api url
                  api.url = paste0(
                    "https://generativelanguage.googleapis.com/",
                    model@version,
                    "/models/",
                    model@model,
                    ":generateContent?key=",
                    model@api
                  )
                  if (model@proxy) {
                    api.url = paste0(
                      "https://api.genai.gd.edu.kg/google/",
                      model@version,
                      "/models/",
                      model@model,
                      ":generateContent?key=",
                      model@api
                    )
                  }

                  # Initialize the request body
                  requestNewContent = list(list(role = "user",
                                                parts = list(text = prompt)))
                  requestBody = as.list(model@chat.history)
                  requestBody$contents = append(requestBody$contents, requestNewContent)

                  # Get the safety settings
                  safety.setting = get.safety.setting(model)
                  if (length(safety.setting) > 0) {
                    requestBody$safetySettings <- safety.setting
                  }

                  # Get the generation configuration
                  generation.config = get.generation.config(model)
                  if (length(generation.config) > 0) {
                    requestBody$generationConfig <- generation.config
                  }

                  # Convert the request as JSON format
                  requestBodyJSON = jsonlite::toJSON(requestBody,
                                                     auto_unbox = TRUE,
                                                     pretty = TRUE)

                  # Send request and get response
                  response = httr::POST(
                    url = api.url,
                    body = requestBodyJSON,
                    httr::add_headers("Content-Type" = "application/json")
                  )
                  responseJSON = httr::content(response, "parsed")

                  # Check for harmful prompt
                  if (!is.null(responseJSON$promptFeedback$blockReason)) {
                    stop("The prompt may contain harmful content.")
                  }

                  # Check for response error
                  if (!is.null(responseJSON$error)) {
                    stop(responseJSON$error$message)
                  }

                  # Save the most recent prompt to the chat history
                  model@chat.history$contents <- append(model@chat.history$contents, requestNewContent)

                  # Save the most recent model response to the chat history
                  respondContent = list(list(
                    role = "model",
                    parts = list(text = responseJSON$candidates[[1]]$content$parts[[1]]$text)
                  ))
                  model@chat.history$contents <- append(model@chat.history$contents, respondContent)

                  if (model@verbose) {
                    get.formated.confguration(requestBody, prompt)
                    cat("============================================================\n")
                    cat("   Chat history \n")
                    cat("------------------------------------------------------------\n\n")
                    chat.history.print(google.model)
                    cat("============================================================\n\n\n\n")
                  }

                  # Get the response text
                  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
                }

#' Chat Edit
#'
#' @export
chat.edit <- S7::new_generic("chat.edit", c("model", "message.to.edit", "prompt"))
S7::method(chat.edit,
           list(genai.google,
                class_numeric,
                class_character)) <- function(model,
                                              message.to.edit,
                                              prompt) {
                  # Check if there are messages in the chat history
                  if (length(model@chat.history$contents) == 0) {
                    stop("Unable to edit any messages as the chat history is devoid of content.")
                  } 
                  
                  # Check message.to.edit
                  if (message.to.edit %% 2 == 0) {
                    stop("Invalid value for message.to.edit. You can only edit messages sent by a user role. Please use chat.history.print() to review the formatted chat history.")
                  }
                  
                  # Get api url
                  api.url = paste0(
                    "https://generativelanguage.googleapis.com/",
                    model@version,
                    "/models/",
                    model@model,
                    ":generateContent?key=",
                    model@api
                  )
                  if (model@proxy) {
                    api.url = paste0(
                      "https://api.genai.gd.edu.kg/google/",
                      model@version,
                      "/models/",
                      model@model,
                      ":generateContent?key=",
                      model@api
                    )
                  }
                  
                  # Initialize the request body
                  requestNewContent = list(list(role = "user",
                                                parts = list(text = prompt)))
                  requestBody = as.list(model@chat.history)
                  requestBody$contents = append(requestBody$contents[1:message.to.edit - 1], 
                                                requestNewContent)

                  # Get the safety settings
                  safety.setting = get.safety.setting(model)
                  if (length(safety.setting) > 0) {
                    requestBody$safetySettings <- safety.setting
                  }

                  # Get the generation configuration
                  generation.config = get.generation.config(model)
                  if (length(generation.config) > 0) {
                    requestBody$generationConfig <- generation.config
                  }

                  # Convert the request as JSON format
                  requestBodyJSON = jsonlite::toJSON(requestBody,
                                                     auto_unbox = TRUE,
                                                     pretty = TRUE)

                  # Send request and get response
                  response = httr::POST(
                    url = api.url,
                    body = requestBodyJSON,
                    httr::add_headers("Content-Type" = "application/json")
                  )
                  responseJSON = httr::content(response, "parsed")

                  # Check for harmful prompt
                  if (!is.null(responseJSON$promptFeedback$blockReason)) {
                    stop("The prompt may contain harmful content.")
                  }

                  # Check for response error
                  if (!is.null(responseJSON$error)) {
                    stop(responseJSON$error$message)
                  }

                  # Save the most recent prompt to the chat history
                  model@chat.history$contents <- append(model@chat.history$contents[1:message.to.edit - 1],
                                                        requestNewContent)

                  # Save the most recent model response to the chat history
                  respondContent = list(list(
                    role = "model",
                    parts = list(text = responseJSON$candidates[[1]]$content$parts[[1]]$text)
                  ))
                  model@chat.history$contents <- append(model@chat.history$contents, respondContent)

                  if (model@verbose) {
                    get.formated.confguration(requestBody, prompt)
                    cat("============================================================\n")
                    cat("   Chat history \n")
                    cat("------------------------------------------------------------\n\n")
                    chat.history.print(google.model)
                    cat("============================================================\n\n\n\n")
                  }

                  # Get the response text
                  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
                }

#' Chat History Reset
#'
#' @export
chat.history.reset <- S7::new_generic("chat.history.reset", c("model"))
S7::method(chat.history.reset, genai.google) <- function(model) {
  model@chat.history$contents <- list()
}

#' Chat History Print
#'
#' @export
chat.history.print <- S7::new_generic("chat.history.print", c("model"))
S7::method(chat.history.print, genai.google) <- function(model) {
  chat.length = length(model@chat.history$contents)
  if (chat.length > 0) {
    for (i in 1:chat.length) {
      cat(sprintf("------------------------ Message %2d ------------------------\n", i))
      cat("Role:", model@chat.history$contents[[i]]$role, "\n")
      cat("Text:", model@chat.history$contents[[i]]$parts$text, "\n\n")
    }
  }
}


#' @noRd
get.safety.setting <- new_generic("get.safety.setting", "model")
method(get.safety.setting, genai.google) <- function(model) {
  raw.harm.category = c(
    harm.category.dangerous.content = "HARM_CATEGORY_DANGEROUS_CONTENT",
    harm.category.harassment = "HARM_CATEGORY_HARASSMENT",
    harm.category.hate.speech = "HARM_CATEGORY_HATE_SPEECH",
    harm.category.sexually.explicit = "HARM_CATEGORY_SEXUALLY_EXPLICIT"
  )
  raw.harm.block.threshold = c(
    "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
    "BLOCK_LOW_AND_ABOVE",
    "BLOCK_MEDIUM_AND_ABOVE",
    "BLOCK_ONLY_HIGH",
    "BLOCK_NONE"
  )
  filled.harm <-
    lapply(names(raw.harm.category), function(harm) {
      if (length(prop(google.model, harm)) > 0) {
        safety.setting.object <- list("category" = raw.harm.category[harm],
                                      "threshold" = raw.harm.block.threshold[prop(google.model, harm)])
        return(safety.setting.object)
      } else {
        return(NULL)
      }
    })
  filled.harm <- Filter(Negate(is.null), filled.harm)
  return(filled.harm)
}

#' @noRd
get.generation.config <- new_generic("get.generation.config", "model")
method(get.generation.config, genai.google) <- function(model) {
  configuration = list()
  if (length(model@stop.sequences) > 0) {
    configuration$stopSequences = model@stop.sequences
  }
  if (length(model@candidate.count) > 0) {
    configuration$candidateCount = model@candidate.count
  }
  if (length(model@max.output.tokens) > 0) {
    configuration$maxOutputTokens = model@max.output.tokens
  }
  if (length(model@temperature) > 0) {
    configuration$temperature = model@temperature
  }
  if (length(model@top.p) > 0) {
    configuration$topP = model@top.p
  }
  if (length(model@top.k) > 0) {
    configuration$topK = model@top.k
  }
  return(configuration)
}

#' @noRd
get.formated.confguration <- function(request.body, prompt) {
  if (!is.null(request.body$safetySettings)) {
    cat("============================================================\n")
    cat("   Safety Settings\n")
    cat("------------------------------------------------------------\n")
    for (i in 1:length(request.body$safetySettings)) {
      cat(
        paste0(request.body$safetySettings[[i]]$category, ":"),
        request.body$safetySettings[[i]]$threshold,
        "\n"
      )
    }
    cat("============================================================\n\n\n")
  }
  if (!is.null(request.body$generationConfig)) {
    cat("============================================================\n")
    cat("   Generation Configuration\n")
    cat("------------------------------------------------------------\n")
    has.stop.sequences = FALSE
    if (!is.null(request.body$generationConfig$stopSequences)) {
      has.stop.sequences = TRUE
      cat(
        "stopSequences:",
        paste0(
          request.body$generationConfig$stopSequences,
          collapse = ", "
        ),
        "\n"
      )
    }
    config.length = length(request.body$generationConfig)
    config.names = names(request.body$generationConfig)
    if (has.stop.sequences) {
      if (config.length > 1) {
        for (i in 2:config.length) {
          cat(paste0(config.names[i], ":"),
              request.body$generationConfig[[config.names[i]]],
              "\n")
        }
      }
    }
    else {
      for (i in 1:config.length) {
        cat(paste0(config.names[i], ":"),
            request.body$generationConfig[[config.names[i]]],
            "\n")
      }
    }
    cat("============================================================\n\n\n")
  }
  cat("============================================================\n")
  cat("   Prompt\n")
  cat("------------------------------------------------------------\n")
  cat(prompt, "\n")
  cat("============================================================\n\n\n")
}
