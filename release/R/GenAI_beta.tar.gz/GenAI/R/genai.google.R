#' @noRd
genai.google <- S7::new_class(
  package = "GenAI",
  name = "genai.google",
  properties = list(
    api = class_character
  )
)

#' Google Gemini Pro Object
#'
#' @export
google.gemini.pro <- S7::new_class(
  package = "GenAI",
  name = "google.gemini.pro",
  parent = genai.google,
  properties = list(
    model = new_property(class_character, default = "gemini-pro"),
    version = class_character,
    proxy = new_property(class_logical, default = FALSE),
    verbose = new_property(class_logical, default = FALSE),
    chat.history = new_property(class_environment,
                                default = listenv::listenv(contents = list())),
    harm.category.dangerous.content = class_numeric,
    harm.category.harassment = class_numeric,
    harm.category.hate.speech = class_numeric,
    harm.category.sexually.explicit = class_numeric,
    stop.sequences = class_list,
    candidate.count = class_numeric,
    max.output.tokens = class_numeric,
    temperature = class_numeric,
    top.p = class_numeric,
    top.k = class_numeric
  ),
  validator = function(self) {
    # Check harm categories
    invalid.harm <- lapply(names(google.gemini.pro@properties[7:10]), function(harm) {
      if (length(prop(self, harm)) > 0 && is.na(match(prop(self, harm), c(1, 2, 3, 4, 5)))) {
        return(paste0("Invalid value for ", harm, ". It must be 1, 2, 3, 4, or 5.\n"))
      }
    })
    invalid.harm <- Filter(Negate(is.null), invalid.harm)
    if (length(invalid.harm) > 0) {
      stop(invalid.harm)
    }

    # Check stop sequence
    if (length(self@stop.sequences) > 5) {
      stop("Invalid value for stop.sequence. It can only have at most 5 strings.")
    }

    # Check model, version, and proxy
    json.data = jsonlite::fromJSON("https://genai.gd.edu.kg/model.json")
    if (is.na(match(self@model, json.data$google$model))) {
      stop("Invalid value for model. Refer to 'available.models()' to view the supported models.")
    }
    if (is.na(match(self@version, json.data$google$version))) {
      stop(
        "Invalid value for version. Refer to 'available.models()' to view the supported versions."
      )
    }
    if (is.na(match(self@proxy, c(TRUE, FALSE)))) {
      stop("Invalid value for proxy. It must be either TRUE or FALSE.")
    }

    # Check connection
    api.url = paste0(
      "https://generativelanguage.googleapis.com/",
      self@version,
      "/models/",
      self@model,
      "?key=",
      self@api
    )
    if (self@proxy) {
      api.url = paste0(
        "https://api.genai.gd.edu.kg/google/",
        self@version,
        "/models/",
        self@model,
        "?key=",
        self@api
      )
    }
    response = httr::GET(url = api.url,
                         httr::add_headers("Content-Type" = "application/json"))
    responseJSON = httr::content(response, "parsed")
    if (!is.null(responseJSON$error)) {
      stop(responseJSON$error$message)
    }
    if (response$status_code != 200) {
      stop(
        "Invalid parameter(s) detected. Please check the values for api, model, version, and proxy."
      )
    }
  }
)

#' @noRd
get.safety.setting <- new_generic("get.safety.setting", "model")
method(get.safety.setting, google.gemini.pro) <- function(model) {
  raw.harm.category = c(
    harm.category.dangerous.content = "HARM_CATEGORY_DANGEROUS_CONTENT",
    harm.category.harassment = "HARM_CATEGORY_HARASSMENT",
    harm.category.hate.speech = "HARM_CATEGORY_HATE_SPEECH",
    harm.category.sexually.explicit = "HARM_CATEGORY_SEXUALLY_EXPLICIT"
  )
  raw.harm.block.threshold = c(
    "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
    "BLOCK_LOW_AND_ABOVE",
    "BLOCK_MEDIUM_AND_ABOVE",
    "BLOCK_ONLY_HIGH",
    "BLOCK_NONE"
  )
  filled.harm <-
    lapply(names(raw.harm.category), function(harm) {
      if (length(prop(google.model, harm)) > 0) {
        safety.setting.object <- list("category" = raw.harm.category[harm],
                                      "threshold" = raw.harm.block.threshold[prop(google.model, harm)])
        return(safety.setting.object)
      } else {
        return(NULL)
      }
    })
  filled.harm <- Filter(Negate(is.null), filled.harm)
  return(filled.harm)
}

#' @noRd
get.generation.config <- new_generic("get.generation.config", "model")
method(get.generation.config, google.gemini.pro) <- function(model) {
  configuration = list()
  if (length(model@stop.sequences) > 0) {
    configuration$stopSequences = model@stop.sequences
  }
  if (length(model@candidate.count) > 0) {
    configuration$candidateCount = model@candidate.count
  }
  if (length(model@max.output.tokens) > 0) {
    configuration$maxOutputTokens = model@max.output.tokens
  }
  if (length(model@temperature) > 0) {
    configuration$temperature = model@temperature
  }
  if (length(model@top.p) > 0) {
    configuration$topP = model@top.p
  }
  if (length(model@top.k) > 0) {
    configuration$topK = model@top.k
  }
  return(configuration)
}

#' @noRd
get.formated.confguration <- function(request.body, prompt) {
  if (!is.null(request.body$safetySettings)) {
    cat("============================================================\n")
    cat("   Safety Settings\n")
    cat("------------------------------------------------------------\n")
    for (i in 1:length(request.body$safetySettings)) {
      cat(
        paste0(request.body$safetySettings[[i]]$category, ":"),
        request.body$safetySettings[[i]]$threshold,
        "\n"
      )
    }
    cat("============================================================\n\n\n")
  }
  if (!is.null(request.body$generationConfig)) {
    cat("============================================================\n")
    cat("   Generation Configuration\n")
    cat("------------------------------------------------------------\n")
    has.stop.sequences = FALSE
    if (!is.null(request.body$generationConfig$stopSequences)) {
      has.stop.sequences = TRUE
      cat(
        "stopSequences:",
        paste0(
          request.body$generationConfig$stopSequences,
          collapse = ", "
        ),
        "\n"
      )
    }
    config.length = length(request.body$generationConfig)
    config.names = names(request.body$generationConfig)
    if (has.stop.sequences) {
      if (config.length > 1) {
        for (i in 2:config.length) {
          cat(paste0(config.names[i], ":"),
              request.body$generationConfig[[config.names[i]]],
              "\n")
        }
      }
    }
    else {
      for (i in 1:config.length) {
        cat(paste0(config.names[i], ":"),
            request.body$generationConfig[[config.names[i]]],
            "\n")
      }
    }
    cat("============================================================\n\n\n")
  }
  cat("============================================================\n")
  cat("   Prompt\n")
  cat("------------------------------------------------------------\n")
  cat(prompt, "\n")
  cat("============================================================\n\n\n")
}
