#' Save Chat History
#'
#' This function saves a chat history along with a generative AI object as a JSON file.
#'
#' @param genai.object A generative AI object containing necessary and correct information.
#' @param file.name A character string representing the name of the JSON file for the chat history.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful chat
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}.
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @export
chat.history.save = function(genai.object, file.name) {
  genai.object$chat.history.save(file.name)
}
