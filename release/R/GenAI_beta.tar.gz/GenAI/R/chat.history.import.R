#' Import Chat History
#'
#' This function export the chat history along with a generative AI object in list
#' or json format.
#'
#' @param genai.object A generative AI object containing necessary and correct information.
#' @param new.chat.history A \code{list} or a \code{json} object containing correct chat history.
#'
#' @details Providing accurate and valid information for each argument is crucial for successful chat
#' generation by the generative AI model. If any parameter is incorrect, the function responds with an
#' error message based on the API feedback. To view all supported generative AI models, use the
#' function \code{\link{available.models}}.
#'
#' @seealso
#' \href{https://genai.gd.edu.kg/r/documentation/}{GenAI - R Package "GenAI" Documentation}
#'
#' @export
chat.history.import = function(genai.object,
                               new.chat.history) {
  genai.object$chat.history.import(new.chat.history)
}
