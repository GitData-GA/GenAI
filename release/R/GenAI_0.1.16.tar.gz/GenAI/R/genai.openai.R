#' OpenAI Object
#'
#' @export
genai.openai = function(api,
                        model,
                        version,
                        proxy = FALSE,
                        organization.id = NULL) {
  return (genai.openai.class$new(api,
                                 model,
                                 version,
                                 proxy,
                                 organization.id))
}
