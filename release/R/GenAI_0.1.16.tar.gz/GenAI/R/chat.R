#' Chat Generation
#'
#' @export
chat = function(
    genai.object,
    prompt,
    verbose = FALSE,
    config = list()
    ) {
  genai.object$chat(prompt,
                    verbose,
                    config)
}
