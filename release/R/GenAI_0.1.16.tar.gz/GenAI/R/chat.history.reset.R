#' Reset Chat History
#'
#' @export
chat.history.reset = function(genai.object) {
  genai.object$chat.history.reset()
}
