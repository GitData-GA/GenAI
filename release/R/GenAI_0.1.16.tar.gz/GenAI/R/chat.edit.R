#' Chat Edit
#'
#' @export
chat.edit = function(genai.object,
                     prompt,
                     message.to.edit,
                     verbose = FALSE,
                     config = list()) {
  genai.object$chat.edit(prompt,
                         message.to.edit,
                         verbose,
                         config)
}
