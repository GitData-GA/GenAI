#' Google Generative AI Object
#'
#' @export
genai.google = function(api,
                        model,
                        version,
                        proxy = FALSE) {
  return (genai.google.class$new(api,
                                 model,
                                 version,
                                 proxy))
}
