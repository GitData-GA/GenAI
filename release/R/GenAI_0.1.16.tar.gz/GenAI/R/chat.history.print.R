#' Print Chat History
#'
#' @export
chat.history.print = function(genai.object,
                              from = 1,
                              to = NULL) {
  genai.object$chat.history.print(start, end)
}
