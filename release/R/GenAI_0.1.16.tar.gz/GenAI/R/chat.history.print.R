#' Print Chat History
#'
#' @export
chat.history.print = function(genai.object) {
  genai.object$chat.history.print()
}
