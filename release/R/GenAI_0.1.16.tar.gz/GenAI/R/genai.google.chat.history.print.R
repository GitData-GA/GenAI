#' @noRd
genai.google.chat.history.print = function(genai.google.object,
                                           from,
                                           to) {
  if (to < from || from < 1) {
    stop("Invalid value(s) for from or to. from >= 1 and to >= from.")
  }
  chat.length = length(genai.google.object$chat.history$contents)
  if (is.numeric(to)) {
    chat.length = to
  }
  if (chat.length > 0) {
    for (i in from:chat.length) {
      cat(
        sprintf(
          "-------------------------------- Message %2d ---------------------------------\n",
          i
        )
      )
      cat("Role:",
          genai.google.object$chat.history$contents[[i]]$role,
          "\n")
      cat("Text:")
      cat(paste(strwrap(genai.google.object$chat.history$contents[[i]]$parts$text,
                        width = 76, exdent = 0), collapse = "\n"))
      cat("\n\n")
    }
  }
}

