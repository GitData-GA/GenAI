#' @noRd
genai.google.chat.history.print = function(genai.google.object) {
  chat.length = length(genai.google.object$chat.history$contents)
  if (chat.length > 0) {
    for (i in 1:chat.length) {
      cat(
        sprintf(
          "-------------------------------- Message %2d --------------------------------\n",
          i
        )
      )
      cat("Role:",
          genai.google.object$chat.history$contents[[i]]$role,
          "\n")
      cat("Text:")
      cat(paste(strwrap(genai.google.object$chat.history$contents[[i]]$parts$text,
                        width = 76, exdent = 0), collapse = "\n"))
      cat("\n\n")
    }
  }
}

