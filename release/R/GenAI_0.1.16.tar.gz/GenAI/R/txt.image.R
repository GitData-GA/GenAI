#' Text Generation with an Image as Input
#'
#' @export
txt.image = function(genai.object,
                     prompt,
                     image.path,
                     verbose = FALSE,
                     config = list()) {
  genai.object$txt.image(prompt,
                         image.path,
                         verbose,
                         config)
}
