#' @noRd
genai.google.txt = function(genai.google.object,
                            prompt,
                            verbose,
                            config = list(
                              harm.category.dangerous.content = NULL,
                              harm.category.harassment = NULL,
                              harm.category.hate.speech = NULL,
                              harm.category.sexually.explicit = NULL,
                              stop.sequences = NULL,
                              candidate.count = NULL,
                              max.output.tokens = NULL,
                              temperature = NULL,
                              top.p = NULL,
                              top.k = NULL
                            )
                            ) {
  # Check configurations
  if (!is.list(config)) {
    stop("Invalid configuration. It must be a list.")
  }
  config.names = c("harm.category.dangerous.content",
                   "harm.category.harassment",
                   "harm.category.hate.speech",
                   "harm.category.sexually.explicit",
                   "stop.sequences",
                   "candidate.count",
                   "max.output.tokens",
                   "temperature",
                   "top.p",
                   "top.k")
  wrong.config = setdiff(names(config), config.names)
  if (length(wrong.config) > 0) {
    stop("Invalid configuration(s) detected: ", paste0(wrong.config, collapse = ", "))
  }
  if (length(unique(names(config))) != length(names(config))) {
    stop("Invalid configurations. Duplicate parameters detected.")
  }

  # Check harm categories
  invalid.harm = lapply(config.names[1:4], function(harm) {
    if (!is.null(config[[harm]]) && is.na(match(config[[harm]], c(1, 2, 3, 4, 5)))) {
      return(paste0("Invalid value for ", harm, ". It must be 1, 2, 3, 4, or 5.\n"))
    }
  })
  invalid.harm = Filter(Negate(is.null), invalid.harm)
  if (length(invalid.harm) > 0) {
    stop(invalid.harm)
  }

  # Check stop sequence
  if (!is.null(config[["stop.sequences"]]) && !is.list(config[["stop.sequences"]])) {
    stop("Invalid stop.sequence. It must be a list.")
  }
  if (length(config[["stop.sequences"]]) > 5) {
    stop("Invalid value for stop.sequence. It can only have at most 5 strings.")
  }

  # Get api url
  api.url = paste0(
    "https://generativelanguage.googleapis.com/",
    genai.google.object$version,
    "/models/",
    genai.google.object$model,
    ":generateContent?key=",
    genai.google.object$api
  )
  if (genai.google.object$proxy) {
    api.url = paste0(
      "https://api.genai.gd.edu.kg/google/",
      genai.google.object$version,
      "/models/",
      genai.google.object$model,
      ":generateContent?key=",
      genai.google.object$api
    )
  }

  # Initialize the request body
  requestBody = list(contents = list(parts = list(text = prompt)))

  # Get the safety settings
  safety.setting = genai.google.safety.setting(config)
  if (length(safety.setting) > 0) {
    requestBody$safetySettings = safety.setting
  }

  # Get the generation configuration
  generation.config = genai.google.generation.config(config)
  if (length(generation.config) > 0) {
    requestBody$generationConfig = generation.config
  }

  # Convert the request as JSON format
  requestBodyJSON = jsonlite::toJSON(requestBody,
                                     auto_unbox = TRUE,
                                     pretty = TRUE)

  # Send request and get response
  response = httr::POST(
    url = api.url,
    body = requestBodyJSON,
    httr::add_headers("Content-Type" = "application/json")
  )
  responseJSON = httr::content(response, "parsed")

  # Check for harmful prompt
  if (!is.null(responseJSON$promptFeedback$blockReason)) {
    stop("Invalid prompt. The prompt may contain harmful content.")
  }

  # Check for response error
  if (!is.null(responseJSON$error)) {
    stop(responseJSON$error$message)
  }

  if (verbose) {
    genai.google.formated.confguration(requestBody, prompt)
    cat("\n")
  }

  # Get the response text
  return (responseJSON$candidates[[1]]$content$parts[[1]]$text)
}
