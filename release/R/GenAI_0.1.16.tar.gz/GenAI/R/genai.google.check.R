#' @noRd
genai.google.check = function(api, model, version, proxy) {
  json.data = jsonlite::fromJSON("https://genai.gd.edu.kg/model.json")
  if (is.na(match(model, json.data$google$model))) {
    stop("Invalid value for model. Refer to 'available.models()' to view the supported models.")
  }
  if (is.na(match(version, json.data$google$version))) {
    stop("Invalid value for version. Refer to 'available.models()' to view the supported versions.")
  }
  if (!proxy %in% c(TRUE, FALSE)) {
    stop("Invalid value for proxy. It must be either TRUE or FALSE.")
  }
  
  # Check connection
  api.url = paste0(
    "https://generativelanguage.googleapis.com/",
    version,
    "/models/",
    model,
    "?key=",
    api
  )
  if (proxy) {
    api.url = paste0(
      "https://api.genai.gd.edu.kg/google/",
      version,
      "/models/",
      model,
      "?key=",
      api
    )
  }
  response = httr::GET(
    url = api.url,
    httr::add_headers("Content-Type" = "application/json")
  )
  responseJSON = httr::content(response, "parsed")
  if (!is.null(responseJSON$error)) {
    stop(responseJSON$error$message)
  }
  if (response$status_code != 200) {
    stop("Invalid parameter(s) detected. Please check the values for api, model, version, and proxy.")
  }
}