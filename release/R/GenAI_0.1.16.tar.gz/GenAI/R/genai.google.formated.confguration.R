#' @noRd
genai.google.formated.confguration = function(request.body, prompt) {
  if (!is.null(request.body$safetySettings)) {
    cat("============================================================\n")
    cat("   Safety Settings\n")
    cat("------------------------------------------------------------\n")
    for (i in 1:length(request.body$safetySettings)) {
      cat(
        paste0(request.body$safetySettings[[i]]$category, ":"),
        request.body$safetySettings[[i]]$threshold,
        "\n"
      )
    }
    cat("============================================================\n\n\n\n")
  }
  if (!is.null(request.body$generationConfig)) {
    cat("============================================================\n")
    cat("   Generation Configuration\n")
    cat("------------------------------------------------------------\n")
    has.stop.sequences = FALSE
    if (!is.null(request.body$generationConfig$stopSequences)) {
      has.stop.sequences = TRUE
      cat(
        "stopSequences:",
        paste0(
          request.body$generationConfig$stopSequences,
          collapse = ", "
        ),
        "\n"
      )
    }
    config.length = length(request.body$generationConfig)
    config.names = names(request.body$generationConfig)
    if (has.stop.sequences) {
      if (config.length > 1) {
        for (i in 2:config.length) {
          cat(paste0(config.names[i], ":"),
              request.body$generationConfig[[config.names[i]]],
              "\n")
        }
      }
    }
    else {
      for (i in 1:config.length) {
        cat(paste0(config.names[i], ":"),
            request.body$generationConfig[[config.names[i]]],
            "\n")
      }
    }
    cat("============================================================\n\n\n\n")
  }
  cat("============================================================\n")
  cat("   Prompt\n")
  cat("------------------------------------------------------------\n")
  cat(prompt, "\n")
  cat("============================================================\n\n\n\n")
}