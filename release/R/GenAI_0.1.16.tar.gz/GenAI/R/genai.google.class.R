#' @noRd
genai.google.class = R6Class(
  classname = "genai.google",
  public = list(
    # Initialize method
    initialize = function(api, model, version, proxy = FALSE) {
      genai.google.check(api, model, version, proxy)
      private$api = api
      private$model = model
      private$version = version
      private$proxy = proxy
    },
    # Get name
    get.name = function() {
      return(private$name)
    },
    # Text generation
    txt = function(prompt,
                   verbose = FALSE,
                   config = list()) {
      genai.google.txt(private, prompt, verbose, config)
    },
    # Text generation with image as input
    txt.image = function(prompt,
                         image.path,
                         verbose = FALSE,
                         config = list()) {
      genai.google.txt.image(private, prompt, verbose, image.path, config)
    }
  ),
  private = list(
    name = "genai.google.class",
    api = NULL,
    model = NULL,
    version = NULL,
    proxy = FALSE,
    chat.history = listenv::listenv(contents = list())
  )
)
