#' @noRd
genai.google.class = R6Class(
  classname = "genai.google",
  public = list(
    name = "genai.google.class",
    # Initialize method
    initialize = function(api, model, version, proxy = FALSE) {
      genai.google.check(api, model, version, proxy)
      private$api = api
      private$model = model
      private$version = version
      private$proxy = proxy
    },
    # Text generation
    txt = function(prompt, verbose = FALSE, config = list()) {
      genai.google.txt(private, prompt, verbose, config)
    }
  ),
  private = list(
    api = NULL,
    model = NULL,
    version = NULL,
    proxy = FALSE,
    chat.history = listenv::listenv(contents = list())
  )
)

#' Google Generative AI Object Generation
#' 
#' @export
genai.google = function(
    api, 
    model, 
    version, 
    proxy = FALSE) {
  return (genai.google.class$new(api, model, version, proxy))
}