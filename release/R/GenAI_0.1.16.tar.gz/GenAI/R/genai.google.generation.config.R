#' @noRd
genai.google.generation.config = function(config) {
  configuration = list()
  if (!is.null(config[["stop.sequences"]])) {
    configuration$stopSequences = config[["stop.sequences"]]
  }
  if (!is.null(config[["candidate.count"]])) {
    configuration$candidateCount = config[["candidate.count"]]
  }
  if (!is.null(config[["max.output.tokens"]])) {
    configuration$maxOutputTokens = config[["max.output.tokens"]]
  }
  if (!is.null(config[["temperature"]])) {
    configuration$temperature = config[["temperature"]]
  }
  if (!is.null(config[["top.p"]])) {
    configuration$topP = config[["top.p"]]
  }
  if (!is.null(config[["top.k"]])) {
    configuration$topK = config[["top.k"]]
  }
  return(configuration)
}