#' Text Generation
#'
#' @export
txt = function(
    genai.object,
    prompt,
    verbose = FALSE,
    config = list()
    ) {
  genai.object$txt(prompt,
                   verbose,
                   config)
}
