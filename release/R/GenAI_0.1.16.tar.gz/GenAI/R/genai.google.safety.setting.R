#' @noRd
genai.google.safety.setting = function(config) {
  raw.harm.category = c(
    harm.category.dangerous.content = "HARM_CATEGORY_DANGEROUS_CONTENT",
    harm.category.harassment = "HARM_CATEGORY_HARASSMENT",
    harm.category.hate.speech = "HARM_CATEGORY_HATE_SPEECH",
    harm.category.sexually.explicit = "HARM_CATEGORY_SEXUALLY_EXPLICIT"
  )
  raw.harm.block.threshold = c(
    "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
    "BLOCK_LOW_AND_ABOVE",
    "BLOCK_MEDIUM_AND_ABOVE",
    "BLOCK_ONLY_HIGH",
    "BLOCK_NONE"
  )
  filled.harm =
    lapply(names(raw.harm.category), function(harm) {
      if (!is.null(config[[harm]])) {
        safety.setting.object = list("category" = raw.harm.category[harm],
                                     "threshold" = raw.harm.block.threshold[config[[harm]]])
        return(safety.setting.object)
      } else {
        return(NULL)
      }
    })
  filled.harm = Filter(Negate(is.null), filled.harm)
  return(filled.harm)
}